const version = '3.0.1';

const appName = 'Image Downloader';

const appNameShort = 'Image Downloader';

export {
    version,
    appName,
    appNameShort
};

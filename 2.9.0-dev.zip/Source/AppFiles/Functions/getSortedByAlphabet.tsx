const getSortedByAlphabet = () => {
    return {
        A: {
            char: 'A',
            childs: [],
        },
        B: {
            char: 'B',
            childs: []
        },
        C: {
            char: 'C',
            childs: []
        },
        D: {
            char: 'D',
            childs: []
        },
        E: {
            char: 'E',
            childs: []
        },
        F: {
            char: 'F',
            childs: []
        },
        G: {
            char: 'G',
            childs: []
        },
        H: {
            char: 'H',
            childs: []
        },
        I: {
            char: 'I',
            childs: []
        },
        J: {
            char: 'J',
            childs: []
        },
        K: {
            char: 'K',
            childs: []
        },
        L: {
            char: 'L',
            childs: []
        },
        M: {
            char: 'M',
            childs: []
        },
        N: {
            char: 'N',
            childs: []
        },
        O: {
            char: 'O',
            childs: []
        },
        P: {
            char: 'P',
            childs: []
        },
        Q: {
            char: 'Q',
            childs: []
        },
        R: {
            char: 'R',
            childs: []
        },
        S: {
            char: 'S',
            childs: []
        },
        T: {
            char: 'T',
            childs: []
        },
        U: {
            char: 'U',
            childs: []
        },
        V: {
            char: 'V',
            childs: []
        },
        W: {
            char: 'W',
            childs: []
        },
        X: {
            char: 'X',
            childs: []
        },
        Y: {
            char: 'Y',
            childs: []
        },
        Z: {
            char: 'Z',
            childs: []
        },
        none : {
            char: 'All',
            childs: []
        }
    };
};

export default getSortedByAlphabet;
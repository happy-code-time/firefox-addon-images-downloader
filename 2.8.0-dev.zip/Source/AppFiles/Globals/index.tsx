const version = '2.8.0';

const appName = 'Image Downloader';

const appNameShort = 'Image Downloader';

export {
    version,
    appName,
    appNameShort
};

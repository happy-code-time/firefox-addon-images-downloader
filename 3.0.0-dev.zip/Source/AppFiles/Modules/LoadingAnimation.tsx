import * as React from 'react';

class LoadingAnimation extends React.Component
{
    render(){
        return(
            <div className="loading-animation"></div>
        );
    }
}

export default LoadingAnimation;
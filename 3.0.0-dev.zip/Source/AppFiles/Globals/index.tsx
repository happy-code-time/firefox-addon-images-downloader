const version = '3.0.0';

const appName = 'Image Downloader';

const appNameShort = 'Image Downloader';

export {
    version,
    appName,
    appNameShort
};

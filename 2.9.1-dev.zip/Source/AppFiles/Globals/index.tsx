const version = '2.9.1';

const appName = 'Image Downloader';

const appNameShort = 'Image Downloader';

export {
    version,
    appName,
    appNameShort
};
